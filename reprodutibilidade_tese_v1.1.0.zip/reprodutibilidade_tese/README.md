# Reprodução computacional de resultados selecionados

**Versão 1.1.0, com correspondência à tese v09.** Este pacote recalcula métricas selecionadas a partir de arquivos preservados. Não constitui reprodução integral da tese, não repete a campanha física, não reexecuta o modelo histórico e não recalibra parâmetros. Não acessa AWS ou Kafka e não exige arquivos do projeto original.

## Correspondência com a tese v09

Os nomes dos scripts e o campo `table` das saídas e dos valores esperados conservam os identificadores legados para não quebrar comandos e evidências. **Eles não são a numeração atual da tese.** A correspondência abaixo foi informada pelo autor; não foi inferida dos nomes dos arquivos.

| ID legado no pacote | Tema | Correspondência e cobertura na v09 |
|---|---|---|
| 5.1 | Latência | Tabela 5.2: resultados selecionados de E01, E01R, E02, E03, E06, E09B, E09C, E11 e E14 |
| 5.2 | Erro térmico | Tabela 5.3, **somente E13 e E14** |
| 5.5 | Concordância | Tabela 5.6 e métricas do texto: E11 e E13 |
| 5.6 | Recuperação | Tabela 5.7 e indicadores complementares: E13, E12D e E12 suplementar |
| 5.7 | Supervisão | Tabela 5.8 e métricas do texto: E14 |

Não estão cobertos todos os ensaios da tabela de erro térmico, as demais tabelas da tese nem os pacotes completos dos Apêndices C e D. A afirmação anterior sobre exclusão das tabelas com números 5.3 e 5.4 referia-se à numeração legada e não deve ser aplicada à v09.

## Instalação e execução

Ambiente de referência: Python 3.11. Os cálculos usam apenas a biblioteca padrão; `requirements.txt` fixa as dependências dos testes. Após obter o pacote, abra um terminal **dentro desta pasta**.

No PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -B scripts\gerar_tudo.py
.\.venv\Scripts\python.exe -B scripts\verificar_resultados.py
.\.venv\Scripts\python.exe -B -m pytest testes -q --junitxml=saida\testes.xml
```

Em Linux/macOS, use `python3.11 -m venv .venv` e `.venv/bin/python` nos mesmos comandos, com `/` nos caminhos. Apenas a instalação das dependências requer internet. As análises e os testes usam exclusivamente as cópias locais.

**Divergências são preservadas:** a verificação retorna código 1 quando há discrepâncias ou valores não reproduzíveis; os testes correspondentes falham ou são explicitamente não executados. Não ajuste dados ou arredondamentos para obter aprovação. Consulte `RELATORIO_GERACAO.md` antes de interpretar a execução.

| Correspondência na tese v09 | Comando legado, após `python -B` | Arquivo de saída principal |
|---|---|---|
| 5.2 — latência | `scripts/tabela_5_1_latencia.py` | `saida/tabela_5_1_latencia.csv` |
| 5.3 — erro térmico, E13/E14 | `scripts/tabela_5_2_erro_termico.py` | `saida/tabela_5_2_erro_termico.csv` |
| 5.6 e texto — concordância | `scripts/tabela_5_5_concordancia.py` | `saida/tabela_5_5_concordancia.csv` |
| 5.7 e complementos — recuperação | `scripts/tabela_5_6_recuperacao.py` | `saida/tabela_5_6_recuperacao.csv` |
| 5.8 e texto — supervisão | `scripts/tabela_5_7_supervisao.py` | `saida/tabela_5_7_supervisao.csv` |
| Todas | `scripts/gerar_tudo.py` | Todos os CSV/JSON e conciliações de identificadores |
| Comparação com a tese | `scripts/verificar_resultados.py` | `saida/verificacao_valores.json` e `.md` |
| Auditoria de publicação | `scripts/auditar_pacote.py` | `saida/seguranca.json` |

Cada linha de saída identifica a fonte, o ensaio, a unidade e o método. O diretório `saida/` é regenerável e ignorado pelo Git. As evidências atuais ficam em `verificacao/v1.1.0/`. Os arquivos diretamente em `verificacao/` são os registros originais da v1.0.0, preservados sem alteração; seus hashes correspondem ao código arquivado em `historico/v1.0.0/`, não ao código atual.

## O que significam os testes

A v1.0.0 registrou **103 testes de software: 90 comparações de valores esperados e 13 verificações auxiliares**. Não são 103 experimentos nem 103 validações científicas independentes. A revisão documental do autor reexecutou os cálculos e a varredura, mas não aquela suíte pytest.

A v1.1.0 mantém os 90 casos originais e acrescenta a comparação do máximo absoluto de E14: **91 comparações e 15 verificações auxiliares**, total de 106 casos. As duas verificações auxiliares novas exercitam a subtração decimal e sua preservação na serialização/comparação. Consulte o registro da execução atual em `verificacao/v1.1.0/execucao_testes.json`.

## Fontes e métodos

- `dados/brutos/`: cópias byte a byte dos CSV de observações, auditorias JSONL e decisões originais selecionados. SHA-256, origem relativa ao projeto e tamanho estão em `dados/MANIFESTO.md` e `dados/manifesto.json`. Nenhuma amostra foi editada, excluída ou sintetizada.
- `dados/series_preservadas/`: previsões históricas **derivadas**, por amostra, copiadas sem alteração. Foram separadas dos dados brutos para não confundir saída do modelo com medição. O script legado 5.2 recalcula os erros de E13/E14 da Tabela 5.3 da v09 por junção de `id` e instante UTC com a referência processada do CSV bruto. Isso reproduz métricas das previsões arquivadas, não a execução histórica do modelo. Sem a vinculação inequívoca de versão/configuração ao ensaio, a geração original dessas previsões não é reproduzível a partir do pacote.
- `esperado/`: valores fornecidos pelo autor e cópia do resumo histórico indicado para latência (ID legado 5.1, Tabela 5.2 da v09). A procedência `bruto` ou `tese` é a classificação declarada pelo autor, não uma certificação automática. O resumo consolidado é fonte **apenas dos valores esperados**, nunca entrada dos scripts de cálculo.
- Latência: diferença entre `ingestion_ts` e `generation_ts`, em milissegundos. Quantil linear na posição `(n-1)*p`, com todos os registros do arquivo, sem corte inicial ou remoção de extremos. A coluna de latência armazenada serve somente à verificação complementar.
- Erro térmico: `e = T_estimada - T_referencia`. O viés é a média desse erro. O resíduo da API tem sinal oposto e é conferido com a inversão correspondente. A referência é a temperatura processada, não uma segunda medição calibrada independente.
- Precisão térmica: temperaturas lidas diretamente como decimais; estatísticas com precisão decimal de 40 dígitos. O campo textual `value_decimal` preserva essa representação em CSV/JSON e é prioritário na verificação. O campo numérico `value` permanece para compatibilidade. Assim, `|28.6746 - 30.5101| = 1.8355`, arredondado a três casas para `1.836`, sem ampliar tolerância nem modificar o valor da tese.
- Concordância: somente pares com contato manual e inferência em `ON`/`OFF`. A acurácia global e a balanceada usam os **mesmos pares e a mesma referência GPIO manual**; a balanceada é a média dos recalls de OFF e ON. A diferença decorre da agregação por classe e do desbalanceamento, não de uma melhoria de instrumentação. A regra constante OFF usa exatamente esses pares.
- Recuperação: identificador composto por sequência e instante de geração; mensagens bufferizadas e drenadas são conjuntos distintos, confrontados com o RDS. Contagens de eventos também são preservadas. A idade do buffer é o campo registrado no evento de drenagem, não o tempo sem broker. O ACK inclui os eventos diretos e drenados com medição disponível. Lacunas de sequência são internas ao conjunto observado e não demonstram entrega integral nem amostragem contínua.
- Supervisão: contagem das decisões arquivadas. A duração do supervisor é distinta da duração de coleta térmica. Recomendações e eventos do operador não demonstram acionamento automático.
- Tolerância: comparação por arredondamento decimal `ROUND_HALF_EVEN` na precisão fornecida. Para latência conserva-se a precisão literal do CSV indicado, pois outra precisão da tese não foi fornecida. Não há tolerância percentual adicional.

## Limitações que acompanham os resultados

1. E09A: não há dados brutos preservados; comparação Wi-Fi/Ethernet não reproduzível a partir do pacote. Faltam o CSV integral e a auditoria do ensaio Wi-Fi.
2. GPIO17: contato fechado manualmente pelo operador em paralelo à manobra do motor. É independente da cadeia térmica, mas **não mede automaticamente a energização**.
3. E14: sem referência GPIO registrada. As decisões preservadas indicam modo `shadow`; as manobras foram manuais, não por relé comandado e verificado.
4. **O desvio residual entre os relógios não foi caracterizado independentemente.** Isso não comprova ausência de sincronização. A diferença entre timestamps pode incluir esse desvio e não equivale, por si só, a uma medição calibrada de atraso unidirecional.
5. E13: recuperar todas as mensagens do buffer não implica provar entrega de todos os eventos do ensaio. A conciliação preserva também os envios diretos ausentes do export e os intervalos das duas fontes, sem atribuir causa não demonstrada.
6. As previsões históricas, as configurações do modelo e as versões atuais do código não devem ser confundidas. O pacote não recalibra parâmetros nem substitui o histórico por resultados novos.
7. A revisão de dados pessoais combinou padrões automáticos e inspeção dos campos e dos eventos manuais. O resultado reportado é **nenhuma ocorrência dos padrões procurados**, não uma garantia de ausência de qualquer informação sensível. Identificadores de equipamento e endereços privados da bancada foram conservados e devem passar pela revisão institucional antes da publicação.

## Publicação

O Git foi inicializado somente nesta pasta, sem remoto, envio ou commit. Consulte `LICENCA_A_DEFINIR.md`: nenhuma licença foi concedida automaticamente. Revise também o relatório e os arquivos antes de adicionar ao Git. Não acrescente configurações de acesso. Arquivos acima de 50 MB devem usar Git LFS ou depósito separado, como Zenodo, em vez de inclusão direta; o relatório registra a checagem de tamanho.

Arquivo identificado: `distribuicao/reprodutibilidade_tese_v1.1.0.zip`, acompanhado de SHA-256 e inventário do conteúdo. Essa é uma **cópia local**, não um endereço público nem confirmação de entrega ao orientador. A pendência de acesso permanece até o envio efetivo ou publicação. Veja `INCORPORACAO_TESE_v09.md` para o texto do Apêndice B e a atualização da §7.5.1.
