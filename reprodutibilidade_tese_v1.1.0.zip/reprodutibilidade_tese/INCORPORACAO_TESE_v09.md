# Incorporação à tese v09

Os trechos abaixo são sugestões de inserção; o arquivo da tese não foi alterado.

## Ao final do Apêndice B

Foi organizado um pacote autocontido para a reprodução computacional de resultados selecionados da tese, composto por arquivos preservados, scripts de cálculo, valores esperados e registros de verificação. Na primeira versão, o recálculo apresentou concordância com os 90 valores especificados, nas precisões declaradas. A revisão 1.1.0 mantém esses casos e acrescenta a verificação do erro absoluto máximo de E14, utilizando aritmética decimal para preservar o arredondamento de 1,8355 °C para 1,836 °C. Para as métricas térmicas de E13 e E14, foram utilizadas previsões históricas arquivadas, sem reexecução do modelo que as produziu. O pacote não constitui repetição da campanha física nem reprodução integral dos resultados da tese.

Identificação da revisão: `reprodutibilidade_tese_v1.1.0.zip`. O resumo criptográfico SHA-256 é fornecido no arquivo de mesmo nome com sufixo `.sha256`. A cópia foi preparada localmente; antes de apresentar o material como acessível ao orientador ou à banca, registrar aqui o endereço efetivo de depósito, ou a data e o meio da entrega confirmada. Não foi gerado URL público e não há confirmação de envio.

## Ajuste da §7.5.1

A organização do pacote de reprodução computacional de resultados selecionados foi concluída. Permanecem pendentes a definição da licença aplicável e a disponibilização efetiva do material, por entrega de cópia identificada ou depósito em endereço acessível. A ampliação da cobertura para outros ensaios, a reprodução da execução histórica do modelo e os pacotes completos dos Apêndices C e D não são abrangidos por esta entrega.

## Cuidados de interpretação

- Os 103 testes originais são 90 comparações de valores e 13 verificações auxiliares de software, não experimentos independentes.
- A suíte da revisão 1.1.0 contém 91 comparações e 15 verificações auxiliares; cite seus resultados apenas com o respectivo registro de execução.
- O desvio residual entre os relógios não foi caracterizado independentemente; isso não demonstra ausência de sincronização.
- O resultado de segurança se limita aos padrões procurados, sem garantia geral de ausência de informação sensível.
- A numeração vigente é a da tabela de correspondência no README; nomes de scripts e campos preservam IDs legados.
