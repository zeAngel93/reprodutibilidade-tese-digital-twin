# Licença a definir

Nenhuma licença foi escolhida ou concedida por este pacote.

MIT ou Apache-2.0 são opções frequentemente consideradas para código; CC BY 4.0 é uma opção frequentemente considerada para dados e documentação. Essas possibilidades são indicativas, não uma recomendação jurídica nem autorização de reutilização.

A escolha cabe ao autor e pode depender da política institucional, da titularidade, das condições dos financiadores e de direitos de terceiros. Antes de publicar, confirme as permissões sobre cada material e registre explicitamente a licença aplicável a código, dados e documentação.
