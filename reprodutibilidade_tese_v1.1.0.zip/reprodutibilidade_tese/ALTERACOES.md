# Histórico de versões

## 1.1.0

- Correspondência explícita entre IDs legados e as Tabelas 5.2, 5.3 (E13/E14), 5.6, 5.7 e 5.8 da tese v09; comandos e IDs preservados.
- Escopo: reprodução computacional de resultados selecionados; não reprodução integral da tese, do modelo histórico ou da campanha física.
- Cálculo térmico decimal e representação decimal preservada até o arredondamento. Máximo absoluto E14: 1,8355 °C, apresentado como 1,836 °C em três casas.
- Uma nova comparação com a tese e duas verificações auxiliares, além das 90 comparações e 13 verificações auxiliares originais.
- Redação corrigida sobre caracterização do desvio residual dos relógios e alcance da varredura de padrões sensíveis.
- Código, especificação e documentos da v1.0.0 preservados em `historico/v1.0.0/`; registros originais em `verificacao/` inalterados. Evidência atual em `verificacao/v1.1.0/`.
- Distribuição local identificada por versão e SHA-256, sem publicação ou envio automático. Nenhum dado de entrada alterado.

## 1.0.0

Versão inicial: 21 arquivos preservados, 90 comparações esperadas e 13 verificações auxiliares. As formulações antigas nos documentos arquivados ficam preservadas como histórico, mas foram substituídas pela presente revisão.
