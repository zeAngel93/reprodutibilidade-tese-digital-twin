"""Compare independent calculations with author-supplied expectations."""
from collections import Counter
from decimal import Decimal, ROUND_HALF_EVEN
from comum import ROOT, OUT, json_read, json_write
from gerar_tudo import generate


def rounded(value, places):
    return Decimal(str(value)).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_EVEN)


def compare(calculated):
    index = {(r['table'],r['run'],r['metric']):r for r in calculated}
    expected = json_read(ROOT / 'esperado/valores_tese.json')['values']
    report = []
    for item in expected:
        key = item['table'],item['run'],item['metric']
        actual = index.get(key)
        actual_number = (actual.get('value_decimal') if actual and actual.get('value_decimal') is not None
                         else actual['value'] if actual else None)
        if actual is None or actual['value'] is None:
            fallback = index.get((item['table'],item['run'],'input_missing'),{})
            status = 'nao_reproduzivel'
            note = fallback.get('note','Grandeza sem observacao suficiente na fonte preservada')
        else:
            status = 'reproduzido' if rounded(actual_number,item['places']) == rounded(item['expected'],item['places']) else 'divergente'
            note = actual['note']
        report.append({**item,'calculated':actual['value'] if actual else None,'status':status,
                       'calculated_decimal':actual.get('value_decimal') if actual else None,
                       'calculated_rounded':str(rounded(actual_number,item['places'])) if actual_number is not None else None,
                       'sources':actual['sources'] if actual else [],'note':note})
    return report


def verify(calculated=None):
    report = compare(generate() if calculated is None else calculated)
    json_write(OUT / 'verificacao_valores.json', report)
    lines = ['# Verificação dos valores', '', 'Valores esperados não entram nos cálculos. Comparação decimal na precisão registrada, ROUND_HALF_EVEN.', '',
             '| ID legado (ver correspondência v09 no README) | Ensaio | Grandeza | Esperado | Calculado (sem arredondar) | Arredondado | Procedência | Situação |',
             '|---|---|---|---:|---:|---:|---|---|']
    for row in report:
        value = row['calculated_decimal'] if row['calculated_decimal'] is not None else row['calculated']
        lines.append(f"| {row['table']} | {row['run']} | `{row['metric']}` | {row['expected']} | {value} | {row['calculated_rounded']} | {row['provenance']} | {row['status']} |")
    (OUT / 'verificacao_valores.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return report


if __name__ == '__main__':
    result = verify()
    counts = dict(Counter(row['status'] for row in result))
    print(counts)
    for row in result:
        if row['status'] != 'reproduzido':
            print(row['table'],row['run'],row['metric'], 'expected=',row['expected'], 'calculated=',row['calculated'],row['status'])
    raise SystemExit(1 if any(row['status'] != 'reproduzido' for row in result) else 0)
