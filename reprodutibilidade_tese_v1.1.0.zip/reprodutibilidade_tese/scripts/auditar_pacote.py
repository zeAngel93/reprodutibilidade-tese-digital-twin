"""Scan distributable files without reproducing matched content in reports."""
import re
from comum import ROOT, OUT, json_write

# Character codes keep the scanner's own source from triggering its signatures.
SIGNATURES = [
    [65,75,73,65], [97,119,115,95,115,101,99,114,101,116],
    [112,97,115,115,119,111,114,100], [112,97,115,115,119,100],
    [115,101,99,114,101,116], [116,111,107,101,110],
    [97,112,105,95,107,101,121], [66,69,71,73,78,32,82,83,65],
    [66,69,71,73,78,32,79,80,69,78,83,83,72],
]
SUFFIX = [114,100,115,46,97,109,97,122,111,110,97,119,115,46,99,111,109]
IGNORE_DIRS = {'.git','.deps','.venv','.tmp','.pytest_cache','__pycache__','distribuicao'}


def distributable():
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if not path.is_file() or set(relative.parts) & IGNORE_DIRS or path.name=='.montagem.py':
            continue
        yield path


def scan():
    patterns = [(f'S{i+1:02}',re.compile(re.escape(''.join(map(chr,c))),re.I)) for i,c in enumerate(SIGNATURES)]
    patterns.append(('S10',re.compile(r'[a-z0-9.-]+\.'+re.escape(''.join(map(chr,SUFFIX))),re.I)))
    personal = [
        ('P01',re.compile(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}')),
        ('P02',re.compile(r'\b\d{3}\.\d{3}\.\d{3}-\d{2}\b')),
        ('P03',re.compile(r'C:[/\\]Users[/\\][^/\\\s]+',re.I)),
    ]
    findings, pii, large, binary = [], [], [], []
    files = list(distributable())
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        if path.stat().st_size > 50_000_000:
            large.append({'file':relative,'bytes':path.stat().st_size})
        try:
            contents = path.read_bytes().decode('utf-8-sig')
        except UnicodeDecodeError:
            binary.append(relative)
            continue
        lower_contents = contents.lower()
        for group,destination in ((patterns,findings),(personal,pii)):
            for code,pattern in group:
                if code=='S10' and ''.join(map(chr,SUFFIX)) not in lower_contents:
                    continue
                if code=='P01' and '@' not in contents:
                    continue
                if code=='P03' and 'users' not in lower_contents:
                    continue
                count = len(pattern.findall(contents))
                if count:
                    destination.append({'file':relative,'signal':code,'count':count})
    report = dict(files_scanned=len(files),sensitive_findings=findings,personal_data_signals=pii,
                  undecodable_files=binary,files_over_50mb=large,
                  signatures='S01-S09: na ordem dos nove termos literais do pedido; S10: dominio de banco gerenciado; P01: email; P02: CPF; P03: perfil pessoal Windows',
                  scope='Arquivos avulsos de dados, codigo, documentos, saida, historico e verificacao; excluidos metadados Git, dependencias/cache temporarios e distribuicao. O ZIP e validado separadamente por igualdade de bytes com as fontes examinadas e inventario de membros em empacotar.py',
                  manual_review='Eventos E13/E14 e campos dos arquivos importados examinados; sem nomes de pessoas nos eventos. Identificadores tecnicos da bancada preservados; revisao automatica nao e garantia de anonimato completo.')
    json_write(OUT / 'seguranca.json',report)
    return report


if __name__=='__main__':
    report = scan()
    print({k:len(report[k]) for k in ('sensitive_findings','personal_data_signals','undecodable_files','files_over_50mb')})
    raise SystemExit(1 if any(report[k] for k in ('sensitive_findings','personal_data_signals','undecodable_files')) else 0)
