"""Recompute errors from archived predictions joined to raw measurements."""
from decimal import localcontext
from comum import csv_rows, decimal_number, emit, mean, metric, missing, source_names, span_min, timestamp


def key(row):
    return row['id'], timestamp(row['generation_ts'])


def unique_index(rows):
    result = {}
    for row in rows:
        identifier = key(row)
        if identifier in result:
            raise ValueError('Duplicate id/time in thermal join')
        result[identifier] = row
    return result


def error_stats(errors):
    if not errors:
        return {name:None for name in ('mae_c','rmse_c','bias_c','max_abs_error_c')}
    errors = [decimal_number(e) for e in errors]
    with localcontext() as context:
        context.prec = 40
        return {'mae_c':mean([abs(e) for e in errors]),'rmse_c':mean([e*e for e in errors]).sqrt(),
                'bias_c':mean(errors),'max_abs_error_c':max(abs(e) for e in errors)}


def calculate():
    result = []
    for run in ('E13','E14'):
        try:
            data = csv_rows(run)
            predictions = unique_index(csv_rows(run,'predictions'))
            raw = unique_index(data)
            sources = source_names(run,'rds','predictions')
            errors, residual_diffs, reference_diffs = [], [], []
            for identifier,row in raw.items():
                saved = predictions.get(identifier)
                if saved is None:
                    continue
                estimate = decimal_number(saved['dt_predicted_now_c'])
                reference = decimal_number(row['processed_value_c'])
                if estimate is None or reference is None:
                    continue
                error = estimate - reference
                errors.append(error)
                residual = decimal_number(saved.get('dt_measurement_residual_c'))
                if residual is not None:
                    residual_diffs.append(abs(error + residual))
                saved_reference = decimal_number(saved.get('temperature_measured_c'))
                if saved_reference is not None:
                    reference_diffs.append(abs(reference - saved_reference))
            values = {'records':(len(data),'rows'),'paired_samples':(len(errors),'pairs'),
                      'duration_min':(span_min(data),'min'),'raw_without_prediction':(len(raw.keys()-predictions.keys()),'rows'),
                      'prediction_without_raw':(len(predictions.keys()-raw.keys()),'rows'),
                      'api_sign_check_max_difference_c':(max(residual_diffs,default=None),'degC'),
                      'reference_join_max_difference_c':(max(reference_diffs,default=None),'degC')}
            values.update({name:(value,'degC') for name,value in error_stats(errors).items()})
            for name,(value,unit) in values.items():
                result.append(metric('5.2',run,name,value,unit,sources,'e = previsao preservada - temperatura processada bruta; residuo da API tem sinal oposto; junção por id e instante UTC; leitura/subtracao decimal; estatisticas com precisao decimal de 40 digitos'))
        except FileNotFoundError as exc:
            result.append(missing('5.2',run,exc))
    return result


if __name__ == '__main__':
    emit('tabela_5_2_erro_termico',calculate())
