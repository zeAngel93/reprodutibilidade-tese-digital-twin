"""Preserve a real pytest execution and its environment without host paths."""
import importlib.metadata
import os
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from comum import ROOT, OUT, json_write


if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    args = ['-B','-m','pytest','testes','-q','-o','cache_dir=.pytest_cache','--junitxml=saida/testes.xml']
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run([sys.executable,*args],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    output = (result.stdout+'\n'+result.stderr).replace(str(ROOT),'<pacote>')
    (OUT/'execucao_testes.txt').write_text(output,encoding='utf-8')
    suite = ET.parse(OUT/'testes.xml').getroot().find('testsuite') if (OUT/'testes.xml').exists() else None
    cases = suite.findall('testcase') if suite is not None else []
    comparisons = sum(case.get('name','').startswith('test_valor_tese[') for case in cases)
    json_write(OUT/'execucao_testes.json',{
        'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'command':['python',*args],
        'returncode':result.returncode,'python_version':platform.python_version(),
        'package_version':(ROOT/'VERSION').read_text(encoding='utf-8').strip(),
        'comparison_tests':comparisons,'auxiliary_tests':len(cases)-comparisons,
        'dependencies':{name:importlib.metadata.version(name) for name in ('pytest','colorama','iniconfig','packaging','pluggy')},
        'tests':suite.get('tests') if suite is not None else None,
        'failures':suite.get('failures') if suite is not None else None,
        'errors':suite.get('errors') if suite is not None else None,
        'skipped':suite.get('skipped') if suite is not None else None,
        'scope':'offline; sem acesso AWS, Kafka ou equipamento; dependencias de teste isoladas'}
    )
    print(output)
    raise SystemExit(result.returncode)
