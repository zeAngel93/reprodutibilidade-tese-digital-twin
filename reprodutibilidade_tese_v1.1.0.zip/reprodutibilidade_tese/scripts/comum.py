"""Local-only inputs and transparent, unrounded statistics."""
from __future__ import annotations

import ast
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from decimal import Decimal
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'saida'


def json_read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def json_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def relative_path(value):
    path = (ROOT / value).resolve()
    path.relative_to(ROOT)
    return path


def input_path(run, kind):
    source = json_read(ROOT / 'dados/fontes.json').get(run, {}).get(kind)
    if not source:
        raise FileNotFoundError(f'{run}: fonte {kind} nao disponivel em dados/fontes.json')
    path = relative_path(source)
    if not path.is_file():
        raise FileNotFoundError(source)
    return path


def source_names(run, *kinds):
    return [input_path(run, kind).relative_to(ROOT).as_posix() for kind in kinds]


@lru_cache(maxsize=None)
def csv_rows(run, kind='rds'):
    with input_path(run, kind).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def timestamp(value):
    dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if dt.tzinfo is None:
        raise ValueError('Timestamp without timezone')
    return dt.astimezone(timezone.utc)


def seconds(delta):
    return Decimal(delta.days * 86400 + delta.seconds) + Decimal(delta.microseconds) / Decimal(1000000)


def latency_ms(row):
    return seconds(timestamp(row['ingestion_ts']) - timestamp(row['generation_ts'])) * 1000


def number(value):
    if value is None or value == '':
        return None
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('Nonfinite numeric input')
    return result


def decimal_number(value):
    if value is None or value == '':
        return None
    result = Decimal(str(value))
    if not result.is_finite():
        raise ValueError('Nonfinite decimal input')
    return result


def mean(values):
    return sum(values) / len(values) if values else None


def quantile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * Decimal(str(q))
    low = int(index)
    fraction = index - low
    if isinstance(ordered[low], Decimal):
        return ordered[low] + (ordered[min(low + 1, len(ordered)-1)] - ordered[low]) * fraction
    return ordered[low] + (ordered[min(low + 1, len(ordered)-1)] - ordered[low]) * float(fraction)


def span_min(rows, field='generation_ts'):
    times = [timestamp(row[field]) for row in rows]
    return seconds(max(times) - min(times)) / 60 if times else None


def max_gap(rows, field):
    times = sorted(timestamp(row[field]) for row in rows)
    return max((seconds(b-a) for a,b in zip(times,times[1:])), default=None)


def payload(value):
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        parsed = ast.literal_eval(value)
    if not isinstance(parsed, dict):
        raise ValueError('Payload is not a mapping')
    return parsed


def metric(table, run, name, value, unit, sources, note=''):
    value_decimal = str(value) if isinstance(value, Decimal) else None
    if isinstance(value, Decimal):
        value = float(value)
    return dict(table=table, run=run, metric=name, value=value, value_decimal=value_decimal, unit=unit, sources=sources, note=note)


def emit(stem, rows):
    OUT.mkdir(parents=True, exist_ok=True)
    json_write(OUT / f'{stem}.json', rows)
    with (OUT / f'{stem}.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['table','run','metric','value','value_decimal','unit','sources','note'])
        writer.writeheader()
        for row in rows:
            writer.writerow({**row, 'sources':'; '.join(row['sources'])})


def missing(table, run, exc):
    return metric(table,run,'input_missing',None,'',[],f'nao reproduzivel a partir do pacote: {exc}')


def check_hashes():
    for entry in json_read(ROOT / 'dados/manifesto.json'):
        data = relative_path(entry['path']).read_bytes()
        if hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError(f"SHA-256 diferente: {entry['path']}")
