"""Assemble a reviewable report from actual evidence, never inventing results."""
import hashlib
from collections import Counter
from pathlib import Path
from comum import ROOT, OUT, check_hashes, json_read, json_write
from auditar_pacote import scan


def build():
    check_hashes()
    manifest = json_read(ROOT/'dados/manifesto.json')
    results = json_read(OUT/'verificacao_valores.json')
    tests = json_read(OUT/'execucao_testes.json')
    version = (ROOT/'VERSION').read_text(encoding='utf-8').strip()
    evidence_dir = f'verificacao/v{version}'
    calculated = json_read(OUT/'todas_tabelas.json')
    index = {(r['table'],r['run'],r['metric']):r['value'] for r in calculated}
    folder = ROOT/evidence_dir
    folder.mkdir(parents=True,exist_ok=True)
    for filename in ('verificacao_valores.json','verificacao_valores.md','execucao_testes.json','execucao_testes.txt','testes.xml'):
        (folder/filename).write_bytes((OUT/filename).read_bytes())

    lines = ['# Manifesto das fontes', '',
             'Todas as cópias listadas são byte a byte, com SHA-256 igual ao arquivo de origem. As origens são caminhos de procedência, relativos ao projeto original, não dependências de execução. Os scripts abrem somente a coluna `Cópia no pacote`.', '',
             'Arquivos em `series_preservadas` são saídas derivadas do modelo por amostra, não medições brutas. O resumo em `esperado/fontes` é usado somente para os resultados esperados.', '',
             '| Ensaio | Cópia no pacote | Origem no projeto | Bytes | SHA-256 | Descrição |',
             '|---|---|---|---:|---|---|']
    for row in manifest:
        lines.append(f"| {row['run']} | `{row['path']}` | `{row['origin']}` | {row['bytes']} | `{row['sha256']}` | {row['role']} |")
    (ROOT/'dados/MANIFESTO.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    security = scan()
    json_write(folder/'seguranca.json',security)
    counts = Counter(r['status'] for r in results)
    metric_sources = {}
    for row in calculated:
        metric_sources.setdefault((row['table'],row['run']),set()).update(row['sources'])

    def val(run,metric):
        return index.get(('5.6',run,metric))

    total = sum(r['bytes'] for r in manifest)
    lines = ['# Relatório de geração', '',
             f'**Versão {version}: reprodução computacional de resultados selecionados, com correspondência à tese v09.** Revisão limitada a `reprodutibilidade_tese/`. Fontes originais e evidências da v1.0.0 preservadas; nenhuma chamada ao banco, broker ou Raspberry Pi. O Git é local, sem remoto, commit ou envio.', '',
             '## Resultado da verificação', '',
             f"- Valores solicitados: {len(results)}; reproduzidos: {counts['reproduzido']}; divergentes: {counts['divergente']}; não reproduzíveis entre os valores solicitados: {counts['nao_reproduzivel']}.",
             f"- Pytest: {tests['tests']} testes; falhas: {tests['failures']}; erros: {tests['errors']}; não executados: {tests['skipped']}; código de saída: {tests['returncode']}.",
             f"- Composição da suíte atual: {tests['comparison_tests']} comparações de valores esperados e {tests['auxiliary_tests']} verificações auxiliares. São testes de software, não experimentos nem validações científicas independentes.",
             '- A v1.0.0 registrou 90 comparações e 13 verificações auxiliares (103 testes). A presente revisão acrescenta uma comparação e duas verificações auxiliares. A revisão documental do autor não havia reexecutado o pytest; esta execução nova está identificada abaixo.',
             f"- Execução preservada: `{tests['started_utc']}` até `{tests['finished_utc']}`. Python {tests['python_version']}; versões em `requirements.txt` e `{evidence_dir}/execucao_testes.json`.",
             f'- Importados: {len(manifest)} arquivos, {total:,} bytes ({total/1_000_000:.2f} MB decimais).',
             '- SHA-256 das cópias conferido. Testes adicionais verificam sinal, junção sem duplicatas, arredondamento, referência comum entre métricas, fontes ausentes, chave de entrega e leitura restrita ao pacote.',
             '- Os testes numéricos passaram sem alterar observações ou ajustar o cálculo aos resultados esperados. As limitações abaixo não são aprovadas ou eliminadas por esse resultado.', '',
             '## Escopo e limites da reprodução', '',
             '| ID legado preservado | Correspondência na tese v09 |', '|---|---|',
             '| 5.1 — latência | Tabela 5.2, ensaios selecionados |',
             '| 5.2 — erro térmico | Tabela 5.3, somente E13 e E14 |',
             '| 5.5 — concordância | Tabela 5.6 e métricas do texto |',
             '| 5.6 — recuperação | Tabela 5.7 e indicadores complementares |',
             '| 5.7 — supervisão | Tabela 5.8 e métricas do texto |', '',
             '**v09: Tabelas 5.2, 5.6, 5.7 e 5.8 (resultados selecionados):** calculadas a partir de observações, auditorias ou decisões por evento. **Tabela 5.3, somente E13/E14:** erros recalculados das previsões históricas preservadas, unidas à medição processada por identificador e instante. As duas junções foram completas; não se reexecutou o modelo para gerar novas previsões nem se recalibraram parâmetros. Os IDs nas saídas são legados, não a numeração vigente da tese.', '',
             'O máximo absoluto de E14 foi incluído como novo valor esperado: 1,836 °C na tese. A subtração decimal das temperaturas preservadas fornece 1,8355 °C. O campo `value_decimal` mantém essa precisão até a comparação e o arredondamento ROUND_HALF_EVEN; a tolerância não foi ampliada e o valor da tese não foi alterado.', '',
             '**Não reproduzível a partir do pacote:** geração histórica das previsões a partir apenas da temperatura bruta. Falta vinculação verificável da versão e configuração térmica ao instante de cada ensaio. Uma cópia atual do código não supre essa lacuna; nenhuma foi apresentada como se fosse histórica.', '',
             '**Não reproduzível a partir do pacote:** E09A e a comparação Wi-Fi/Ethernet. Falta `20260829_E09A_latency_wifi_wait1000ms/export/sensor_readings_cloud_full_export.csv` e a auditoria correspondente. Não há valor esperado para E09A na lista de comparações; ele não foi contado como aprovado.', '',
             'Não há reprodução integral da tese. Não estão cobertos todos os ensaios da tabela de erro térmico, as demais tabelas nem os pacotes completos dos Apêndices C e D. A exclusão de tabelas numeradas 5.3/5.4 mencionada na primeira versão era relativa à numeração legada e não descreve a cobertura da v09.', '',
             'O contato GPIO é manual, não mede energização. E14 não tem referência GPIO registrada. O desvio residual entre os relógios não foi caracterizado independentemente; isso não comprova ausência de sincronização. A diferença entre timestamps pode incluir esse desvio. Todas essas ressalvas acompanham o README.', '',
             '## E13: buffer e entrega integral', '',
             f"A auditoria registra {val('E13','edge_generated_unique')} identificadores compostos de borda. O export contém {next(r['value'] for r in calculated if r['table']=='5.2' and r['run']=='E13' and r['metric']=='records')} linhas, mas {val('E13','rds_unique')} identificadores compostos únicos: {val('E13','rds_duplicates')} linhas duplicadas por essa chave. Faltam {val('E13','direct_missing_rds')} identificadores de envio direto no export. A diferença simples entre contagens de linhas não é a contagem correta de eventos ausentes.", '',
             f"As {val('E13','buffered')} mensagens bufferizadas foram drenadas e encontradas no RDS. Os ausentes na janela delimitada pelo primeiro e último instante de geração do export são {val('E13','edge_missing_in_rds_time_window')}. Os identificadores e duplicações estão em `saida/E13_conciliacao_identificadores.json`. A localização no início não identifica a causa da ausência nem prova perda física, inicialização tardia ou descarte pelo consumidor.", '',
             'Zero lacunas internas de sequência não demonstra amostragem contínua nem entrega de todos os eventos produzidos. O pacote preserva separadamente lacunas temporais, duplicações e ausências.', '',
             '## Segurança e dados pessoais', '',
             f"Os {len(manifest)} arquivos de entrada passaram por inspeção anterior à cópia. Ocorrências dos padrões solicitados nas entradas: zero; substituições nas entradas: zero. Todas permanecem cópias fiéis.",
             f"A varredura retornou {len(security['sensitive_findings'])} ocorrências dos padrões procurados, {len(security['personal_data_signals'])} sinais automatizados de dados pessoais e {len(security['undecodable_files'])} arquivos não examináveis como UTF-8. Isso não garante ausência de qualquer informação sensível. Relatório em `{evidence_dir}/seguranca.json`; nova varredura por `scripts/auditar_pacote.py`.",
             'As assinaturas S01–S09 correspondem, na ordem, aos nove termos literais do pedido; S10 busca o domínio do banco gerenciado. São construídas por códigos de caracteres no scanner para evitar que a própria definição produza falso positivo no código da ferramenta. O relatório nunca reproduz o conteúdo encontrado.',
             'Os arquivos `operator_events.csv` de E13/E14 foram lidos integralmente: somente horários e rótulos das ações, sem nomes de pessoas. O scanner também procura e-mails, CPF e caminhos de perfis pessoais Windows. Campos dos demais arquivos foram examinados; nomes arbitrários não podem ser excluídos com certeza apenas por padrões automáticos. IDs técnicos, endereços privados e caminhos da bancada não foram alterados.',
             'Dependências de teste foram instaladas de forma isolada nesta pasta, sem modificar o ambiente do projeto. Dependências, caches e metadados internos do Git não fazem parte do material de publicação. Credenciais e metadados de conexão não foram copiados.', '',
             '## Cópias e exclusões', '',
             'Lista completa das cópias, tamanhos, descrições e hashes em [dados/MANIFESTO.md](dados/MANIFESTO.md).', '',
             '| Arquivo no pacote | Ensaio | Bytes | Situação |', '|---|---|---:|---|']
    for row in manifest:
        lines.append(f"| `{row['path']}` | {row['run']} | {row['bytes']} | Cópia fiel; SHA-256 conferido |")
    lines += ['', '| Arquivo ou classe não copiada | Motivo |', '|---|---|']
    for row in json_read(ROOT/'dados/exclusoes.json'):
        lines.append(f"| `{row['origin']}` | {row['reason']} |")
    lines += ['', 'As exclusões por classe descrevem a seleção por lista permitida, não uma alegação de inspeção de todo arquivo alheio ao escopo.', '',
              '## Tamanho e Git', '',
              'Limite examinado: 50.000.000 bytes por arquivo. Nenhuma fonte selecionada excede o limite. O scanner verifica também os resultados e documentos distribuíveis. Para arquivos futuros acima do limite, utilizar Git LFS ou depósito separado, como Zenodo, e não adicioná-los diretamente ao Git.', '',
              'Nenhum arquivo foi adicionado ao índice e nenhum commit ou remoto foi criado. `.gitignore` exclui saídas regeneráveis, ambientes, caches e arquivos de acesso. A licença permanece pendente da decisão do autor.', '',
              '## Resultados individualizados', '',
              'A procedência abaixo preserva a classificação fornecida pelo autor. Para 5.1, os esperados foram extraídos do resumo histórico indicado, inclusive sua precisão literal. Fontes de cálculo são listadas ao final; o JSON preserva a associação em cada resultado.', '',
              '| ID legado (ver correspondência v09 acima) | Ensaio | Grandeza | Esperado | Calculado sem arredondar | Na precisão indicada | Unidade | Procedência | Situação |',
              '|---|---|---|---:|---:|---:|---|---|---|']
    for r in results:
        status = {'reproduzido':'Reproduzido','divergente':'Divergente','nao_reproduzivel':'Não reproduzível a partir do pacote'}[r['status']]
        value = r.get('calculated_decimal') if r.get('calculated_decimal') is not None else r['calculated']
        lines.append(f"| {r['table']} | {r['run']} | `{r['metric']}` | {r['expected']} | {value} | {r['calculated_rounded']} | {r['unit']} | {r['provenance']} | {status} |")
    lines += ['', '## Fontes por cálculo', '']
    for (table,run),paths in sorted(metric_sources.items()):
        lines.append(f"- {table}, {run}: " + '; '.join(f'`{p}`' for p in sorted(paths)))
    lines += ['', '## Evidência de execução', '',
              f'`{evidence_dir}/` preserva comparação, saída do pytest, JUnit XML, ambiente e varredura. `{evidence_dir}/hashes_codigo.json` identifica scripts, testes, requisitos e especificação desta revisão. Os registros originais diretamente em `verificacao/` não foram reescritos e correspondem à v1.0.0, cujo código está em `historico/v1.0.0/`. As execuções futuras escrevem em `saida/`.', '',
              '## Distribuição e acesso', '',
              f'Arquivo local identificado: `distribuicao/reprodutibilidade_tese_v{version}.zip`, com SHA-256 e inventário gerados por `scripts/empacotar.py`. Não houve envio ao orientador nem criação de endereço público. A pendência de acesso permanece até entrega efetiva ou publicação. O arquivo da tese não foi editado; sugestões em `INCORPORACAO_TESE_v09.md`.', '']
    (ROOT/'RELATORIO_GERACAO.md').write_text('\n'.join(lines),encoding='utf-8')
    code_paths = sorted((ROOT/'scripts').glob('*.py')) + sorted((ROOT/'testes').glob('*.py')) + [ROOT/'requirements.txt',ROOT/'esperado/valores_tese.json',ROOT/'dados/fontes.json',ROOT/'VERSION']
    json_write(folder/'hashes_codigo.json',[{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in code_paths])
    security = scan()
    json_write(folder/'seguranca.json',security)
    print(f"Relatorio final: {len(results)} valores, {len(manifest)} fontes.")


if __name__=='__main__':
    build()
