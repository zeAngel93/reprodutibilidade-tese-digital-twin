"""Create a versioned local distribution and verify each archived member."""
import hashlib
import zipfile
from comum import ROOT, check_hashes, json_write
from auditar_pacote import distributable, scan


def build():
    check_hashes()
    report = scan()
    if any(report[k] for k in ('sensitive_findings','personal_data_signals','undecodable_files')):
        raise RuntimeError('Publicacao bloqueada pela varredura; examine saida/seguranca.json')
    version = (ROOT/'VERSION').read_text(encoding='utf-8').strip()
    folder = ROOT/'distribuicao'
    folder.mkdir(exist_ok=True)
    path = folder/f'reprodutibilidade_tese_v{version}.zip'
    if path.exists():
        raise FileExistsError('Distribuicao existente; nao sobrescrever uma versao identificada')
    sources = [p for p in distributable() if p.relative_to(ROOT).parts[0]!='saida']
    oversized = [p.relative_to(ROOT).as_posix() for p in sources if p.stat().st_size>50_000_000]
    if oversized:
        raise RuntimeError(f'Arquivos acima de 50 MB: {oversized}; usar LFS ou deposito separado')
    members = []
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for source in sources:
            source.resolve().relative_to(ROOT)
            relative = source.relative_to(ROOT).as_posix()
            data = source.read_bytes()
            arcname = f'reprodutibilidade_tese/{relative}'
            archive.writestr(arcname,data)
            members.append(dict(path=arcname,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {row['path'] for row in members}
        for row in members:
            if hashlib.sha256(archive.read(row['path'])).hexdigest()!=row['sha256']:
                raise RuntimeError('Conteudo divergente no ZIP')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    path.with_suffix('.zip.sha256').write_text(f'{digest}  {path.name}\n',encoding='ascii')
    json_write(path.with_suffix('.inventario.json'),dict(version=version,file=path.name,bytes=path.stat().st_size,
        sha256=digest,members=members,crc_verified=True,member_hashes_verified=True,
        access='Copia local; sem publicacao nem confirmacao de entrega',
        source_scan=report))
    print(f'{path.name}: {path.stat().st_size} bytes; {len(members)} membros; SHA-256 {digest}')


if __name__=='__main__':
    build()
