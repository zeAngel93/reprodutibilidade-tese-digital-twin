# Registro documental da primeira versão

`v1.0.0/` contém cópias byte a byte dos scripts, testes, requisitos, valores esperados, mapeamento de fontes, README, relatório e evidências da versão inicial. Os 15 hashes originais podem ser conferidos relativos a essa pasta.

Este registro não é um segundo pacote de execução: as 21 fontes originais não foram duplicadas. Elas continuam na raiz do pacote, com os hashes registrados no manifesto. Execute somente os comandos do README atual. O uso da numeração antiga e a afirmação antiga sobre relógios nos documentos históricos não descrevem a posição da revisão atual.
