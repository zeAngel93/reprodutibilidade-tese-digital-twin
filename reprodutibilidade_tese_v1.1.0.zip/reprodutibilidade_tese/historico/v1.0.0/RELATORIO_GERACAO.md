# Relatório de geração

Pacote criado em 21/09/2026, exclusivamente dentro de `reprodutibilidade_tese/`. Os arquivos originais foram apenas lidos; nenhuma chamada ao banco, broker ou Raspberry Pi foi realizada. O Git é local, sem remoto, commit ou envio.

## Resultado da verificação

- Valores solicitados: 90; reproduzidos: 90; divergentes: 0; não reproduzíveis entre os valores solicitados: 0.
- Pytest: 103 testes; falhas: 0; erros: 0; não executados: 0; código de saída: 0.
- Execução preservada: `2026-09-21T15:23:30.671036+00:00` até `2026-09-21T15:24:06.057024+00:00`. Python 3.11.0; versões em `requirements.txt` e `verificacao/execucao_testes.json`.
- Importados: 21 arquivos, 131,832,776 bytes (131.83 MB decimais).
- SHA-256 das cópias conferido. Testes adicionais verificam sinal, junção sem duplicatas, arredondamento, referência comum entre métricas, fontes ausentes, chave de entrega e leitura restrita ao pacote.
- Os testes numéricos passaram sem alterar observações ou ajustar o cálculo aos resultados esperados. As limitações abaixo não são aprovadas ou eliminadas por esse resultado.

## Escopo e limites da reprodução

**Tabelas 5.1, 5.5, 5.6 e 5.7:** calculadas a partir de observações, auditorias ou decisões por evento. **Tabela 5.2:** erros recalculados das previsões históricas preservadas, unidas à medição processada por identificador e instante. As duas junções foram completas; não se reexecutou o modelo para gerar novas previsões.

**Não reproduzível a partir do pacote:** geração histórica das previsões a partir apenas da temperatura bruta. Falta vinculação verificável da versão e configuração térmica ao instante de cada ensaio. Uma cópia atual do código não supre essa lacuna; nenhuma foi apresentada como se fosse histórica.

**Não reproduzível a partir do pacote:** E09A e a comparação Wi-Fi/Ethernet. Falta `20260829_E09A_latency_wifi_wait1000ms/export/sensor_readings_cloud_full_export.csv` e a auditoria correspondente. Não há valor esperado para E09A entre os 90; ele não foi contado como aprovado.

As Tabelas 5.3 e 5.4 não foram especificadas no pedido. Não há alegação de reprodução de todas as tabelas do capítulo para além das cinco enumeradas.

O contato GPIO é manual, não mede energização. E14 não tem referência GPIO registrada. Os relógios de borda e nuvem não foram sincronizados fisicamente; a latência calculada inclui eventual diferença entre relógios. Todas essas ressalvas acompanham o README.

## E13: buffer e entrega integral

A auditoria registra 10491 identificadores compostos de borda. O export contém 10414 linhas, mas 10412 identificadores compostos únicos: 2 linhas duplicadas por essa chave. Faltam 79 identificadores de envio direto no export. A diferença simples entre contagens de linhas não é a contagem correta de eventos ausentes.

As 499 mensagens bufferizadas foram drenadas e encontradas no RDS. Os ausentes na janela delimitada pelo primeiro e último instante de geração do export são 0. Os identificadores e duplicações estão em `saida/E13_conciliacao_identificadores.json`. A localização no início não identifica a causa da ausência nem prova perda física, inicialização tardia ou descarte pelo consumidor.

Zero lacunas internas de sequência não demonstra amostragem contínua nem entrega de todos os eventos produzidos. O pacote preserva separadamente lacunas temporais, duplicações e ausências.

## Segurança e dados pessoais

Os 21 arquivos de entrada passaram por inspeção anterior à cópia. Ocorrências dos padrões solicitados nas entradas: zero; substituições nas entradas: zero. Todas permanecem cópias fiéis.
A varredura dos arquivos distribuíveis retornou 0 ocorrências sensíveis, 0 sinais automatizados de dados pessoais e 0 arquivos não examináveis como UTF-8. Relatório em `verificacao/seguranca.json`; nova varredura por `scripts/auditar_pacote.py`.
As assinaturas S01–S09 correspondem, na ordem, aos nove termos literais do pedido; S10 busca o domínio do banco gerenciado. São construídas por códigos de caracteres no scanner para evitar que a própria definição produza falso positivo no código da ferramenta. O relatório nunca reproduz o conteúdo encontrado.
Os arquivos `operator_events.csv` de E13/E14 foram lidos integralmente: somente horários e rótulos das ações, sem nomes de pessoas. O scanner também procura e-mails, CPF e caminhos de perfis pessoais Windows. Campos dos demais arquivos foram examinados; nomes arbitrários não podem ser excluídos com certeza apenas por padrões automáticos. IDs técnicos, endereços privados e caminhos da bancada não foram alterados.
Dependências de teste foram instaladas de forma isolada nesta pasta, sem modificar o ambiente do projeto. Dependências, caches e metadados internos do Git não fazem parte do material de publicação. Credenciais e metadados de conexão não foram copiados.

## Cópias e exclusões

Lista completa das cópias, tamanhos, descrições e hashes em [dados/MANIFESTO.md](dados/MANIFESTO.md).

| Arquivo no pacote | Ensaio | Bytes | Situação |
|---|---|---:|---|
| `dados/brutos/E01/sensor_readings_cloud_full_export.csv` | E01 | 2224774 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E01R/sensor_readings_cloud_full_export.csv` | E01R | 8653512 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E02/sensor_readings_cloud_full_export.csv` | E02 | 9257573 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E03/sensor_readings_cloud_full_export.csv` | E03 | 9253694 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E06/sensor_readings_cloud_full_export.csv` | E06 | 10897110 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E09B/sensor_readings_cloud_full_export.csv` | E09B | 3195739 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E09C/sensor_readings_cloud_full_export.csv` | E09C | 2721924 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E11/sensor_readings_cloud_full_export.csv` | E11 | 15537167 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E12/sensor_readings_cloud_full_export.csv` | E12 | 3181530 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E12/edge_delivery_audit_3state.jsonl` | E12 | 320675 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E12D/sensor_readings_cloud_full_export.csv` | E12D | 2272140 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E12D/edge_delivery_audit_3state.jsonl` | E12D | 292880 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E13/sensor_readings_cloud_full_export.csv` | E13 | 35820789 | Cópia fiel; SHA-256 conferido |
| `dados/series_preservadas/E13/exp5_cloud_three_state_digital_twin.csv` | E13 | 3186381 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E13/operator_events.csv` | E13 | 551 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E13/edge_delivery_audit_3state.jsonl` | E13 | 4566255 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E14/sensor_readings_cloud_full_export.csv` | E14 | 18561831 | Cópia fiel; SHA-256 conferido |
| `dados/series_preservadas/E14/exp5_cloud_three_state_digital_twin.csv` | E14 | 1568478 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E14/operator_events.csv` | E14 | 130 | Cópia fiel; SHA-256 conferido |
| `dados/brutos/E14/e14_onoff_shadow_control_decisions.csv` | E14 | 306628 | Cópia fiel; SHA-256 conferido |
| `esperado/fontes/resumo_historico_experimentos_3state.csv` | campanha | 13015 | Cópia fiel; SHA-256 conferido |

| Arquivo ou classe não copiada | Motivo |
|---|---|
| `.env e configuracoes de acesso, chaves e arquivos de conexao` | Excluidos por politica de seguranca; nunca copiados |
| `export_metadata.json e rds_connection_evidence.json de todos os ensaios` | Metadados de infraestrutura nao necessarios; podem revelar host ou acesso |
| `codigo de producao da borda, API e consumidor` | Nao necessario para os calculos; pode conter acesso e configuracao de infraestrutura. Este pacote nao executa o sistema fisico |
| `resumos agregados de auditoria e demais tabelas consolidadas` | Nao sao entrada de calculo; priorizados registros originais |
| `exportacoes de E00, E04, E05, E07, E08, E08B, E10, E12B e E12C` | Fora das cinco tabelas e dos casos numericos solicitados |
| `notebooks/runs_3state/20260829_E09A_latency_wifi_wait1000ms/export/sensor_readings_cloud_full_export.csv` | Nao preservado; nao reproduzivel a partir do pacote |

As exclusões por classe descrevem a seleção por lista permitida, não uma alegação de inspeção de todo arquivo alheio ao escopo.

## Tamanho e Git

Limite examinado: 50.000.000 bytes por arquivo. Nenhuma fonte selecionada excede o limite. O scanner verifica também os resultados e documentos distribuíveis. Para arquivos futuros acima do limite, utilizar Git LFS ou depósito separado, como Zenodo, e não adicioná-los diretamente ao Git.

Nenhum arquivo foi adicionado ao índice e nenhum commit ou remoto foi criado. `.gitignore` exclui saídas regeneráveis, ambientes, caches e arquivos de acesso. A licença permanece pendente da decisão do autor.

## Resultados individualizados

A procedência abaixo preserva a classificação fornecida pelo autor. Para 5.1, os esperados foram extraídos do resumo histórico indicado, inclusive sua precisão literal. Fontes de cálculo são listadas ao final; o JSON preserva a associação em cada resultado.

| Tabela | Ensaio | Grandeza | Esperado | Calculado sem arredondar | Na precisão indicada | Unidade | Procedência | Situação |
|---|---|---|---:|---:|---:|---|---|---|
| 5.1 | E01 | `records` | 909 | 909 | 909 | rows | bruto | Reproduzido |
| 5.1 | E01 | `latency_mean_ms` | 1335.5177150715 | 1335.5177150715072 | 1335.5177150715 | ms | bruto | Reproduzido |
| 5.1 | E01 | `latency_p95_ms` | 1865.987 | 1865.987 | 1865.987 | ms | bruto | Reproduzido |
| 5.1 | E01 | `latency_max_ms` | 2853.663 | 2853.663 | 2853.663 | ms | bruto | Reproduzido |
| 5.1 | E01R | `records` | 3470 | 3470 | 3470 | rows | bruto | Reproduzido |
| 5.1 | E01R | `latency_mean_ms` | 1346.0848792507 | 1346.0848792507204 | 1346.0848792507 | ms | bruto | Reproduzido |
| 5.1 | E01R | `latency_p95_ms` | 1868.60855 | 1868.60855 | 1868.60855 | ms | bruto | Reproduzido |
| 5.1 | E01R | `latency_max_ms` | 2617.257 | 2617.257 | 2617.257 | ms | bruto | Reproduzido |
| 5.1 | E02 | `records` | 3719 | 3719 | 3719 | rows | bruto | Reproduzido |
| 5.1 | E02 | `latency_mean_ms` | 1347.3716499059 | 1347.3716499058887 | 1347.3716499059 | ms | bruto | Reproduzido |
| 5.1 | E02 | `latency_p95_ms` | 1868.1418 | 1868.1418 | 1868.1418 | ms | bruto | Reproduzido |
| 5.1 | E02 | `latency_max_ms` | 2866.882 | 2866.882 | 2866.882 | ms | bruto | Reproduzido |
| 5.1 | E03 | `records` | 3715 | 3715 | 3715 | rows | bruto | Reproduzido |
| 5.1 | E03 | `latency_mean_ms` | 1737.3577189771 | 1737.3577189771197 | 1737.3577189771 | ms | bruto | Reproduzido |
| 5.1 | E03 | `latency_p95_ms` | 1873.1177 | 1873.1177 | 1873.1177 | ms | bruto | Reproduzido |
| 5.1 | E03 | `latency_max_ms` | 54912.249 | 54912.249 | 54912.249 | ms | bruto | Reproduzido |
| 5.1 | E06 | `records` | 4363 | 4363 | 4363 | rows | bruto | Reproduzido |
| 5.1 | E06 | `latency_mean_ms` | 1348.5926559707 | 1348.5926559706625 | 1348.5926559707 | ms | bruto | Reproduzido |
| 5.1 | E06 | `latency_p95_ms` | 1866.4313 | 1866.4313 | 1866.4313 | ms | bruto | Reproduzido |
| 5.1 | E06 | `latency_max_ms` | 2874.469 | 2874.469 | 2874.469 | ms | bruto | Reproduzido |
| 5.1 | E09B | `records` | 1336 | 1336 | 1336 | rows | bruto | Reproduzido |
| 5.1 | E09B | `latency_mean_ms` | 1360.4895755988 | 1360.4895755988025 | 1360.4895755988 | ms | bruto | Reproduzido |
| 5.1 | E09B | `latency_p95_ms` | 1828.4115 | 1828.4115 | 1828.4115 | ms | bruto | Reproduzido |
| 5.1 | E09B | `latency_max_ms` | 2231.656 | 2231.656 | 2231.656 | ms | bruto | Reproduzido |
| 5.1 | E09C | `records` | 1143 | 1143 | 1143 | rows | bruto | Reproduzido |
| 5.1 | E09C | `latency_mean_ms` | 1354.676519685 | 1354.6765196850395 | 1354.676519685 | ms | bruto | Reproduzido |
| 5.1 | E09C | `latency_p95_ms` | 1826.6382 | 1826.6382 | 1826.6382 | ms | bruto | Reproduzido |
| 5.1 | E09C | `latency_max_ms` | 2071.91 | 2071.91 | 2071.91 | ms | bruto | Reproduzido |
| 5.1 | E11 | `records` | 5114 | 5114 | 5114 | rows | bruto | Reproduzido |
| 5.1 | E11 | `latency_mean_ms` | 1429.0117061009 | 1429.0117061008996 | 1429.0117061009 | ms | bruto | Reproduzido |
| 5.1 | E11 | `latency_p95_ms` | 1904.54995 | 1904.54995 | 1904.54995 | ms | bruto | Reproduzido |
| 5.1 | E11 | `latency_max_ms` | 2098.222 | 2098.222 | 2098.222 | ms | bruto | Reproduzido |
| 5.1 | E14 | `records` | 6576 | 6576 | 6576 | rows | bruto | Reproduzido |
| 5.1 | E14 | `latency_mean_ms` | 1380.4650629562 | 1380.4650629562043 | 1380.4650629562 | ms | bruto | Reproduzido |
| 5.1 | E14 | `latency_p95_ms` | 1843.94375 | 1843.94375 | 1843.94375 | ms | bruto | Reproduzido |
| 5.1 | E14 | `latency_max_ms` | 12509.366 | 12509.366 | 12509.366 | ms | bruto | Reproduzido |
| 5.2 | E13 | `records` | 10414 | 10414 | 10414 | rows | bruto | Reproduzido |
| 5.2 | E13 | `mae_c` | 0.819 | 0.8192293163049738 | 0.819 | degC | bruto | Reproduzido |
| 5.2 | E13 | `rmse_c` | 0.979 | 0.9787730843647912 | 0.979 | degC | bruto | Reproduzido |
| 5.2 | E13 | `bias_c` | -0.804 | -0.8039098617246011 | -0.804 | degC | bruto | Reproduzido |
| 5.2 | E13 | `max_abs_error_c` | 4.267 | 4.2673999999999985 | 4.267 | degC | bruto | Reproduzido |
| 5.2 | E13 | `duration_min` | 180.46 | 180.46396196666666 | 180.46 | min | bruto | Reproduzido |
| 5.2 | E14 | `records` | 6576 | 6576 | 6576 | rows | tese | Reproduzido |
| 5.2 | E14 | `duration_min` | 109.59 | 109.59424681666667 | 109.59 | min | tese | Reproduzido |
| 5.2 | E14 | `mae_c` | 0.430 | 0.42987948600973125 | 0.430 | degC | tese | Reproduzido |
| 5.2 | E14 | `rmse_c` | 0.536 | 0.5356381326425674 | 0.536 | degC | tese | Reproduzido |
| 5.5 | E13 | `OFF_OFF` | 9742 | 9742 | 9742 | pairs | bruto | Reproduzido |
| 5.5 | E13 | `OFF_ON` | 25 | 25 | 25 | pairs | bruto | Reproduzido |
| 5.5 | E13 | `ON_OFF` | 33 | 33 | 33 | pairs | bruto | Reproduzido |
| 5.5 | E13 | `ON_ON` | 614 | 614 | 614 | pairs | bruto | Reproduzido |
| 5.5 | E11 | `OFF_OFF` | 4530 | 4530 | 4530 | pairs | tese | Reproduzido |
| 5.5 | E11 | `OFF_ON` | 258 | 258 | 258 | pairs | tese | Reproduzido |
| 5.5 | E11 | `ON_OFF` | 64 | 64 | 64 | pairs | tese | Reproduzido |
| 5.5 | E11 | `ON_ON` | 247 | 247 | 247 | pairs | tese | Reproduzido |
| 5.5 | E13 | `agreement_pct` | 99.4431 | 99.4430574227002 | 99.4431 | % | bruto | Reproduzido |
| 5.5 | E13 | `balanced_accuracy_pct` | 97.32 | 97.32178618060469 | 97.32 | % | bruto | Reproduzido |
| 5.5 | E11 | `comparable` | 5099 | 5099 | 5099 | pairs | tese | Reproduzido |
| 5.5 | E11 | `excluded_unknown` | 15 | 15 | 15 | pairs | tese | Reproduzido |
| 5.5 | E11 | `agreement_pct` | 93.69 | 93.68503628162385 | 93.69 | % | tese | Reproduzido |
| 5.5 | E11 | `balanced_accuracy_pct` | 87.02 | 87.01637534350346 | 87.02 | % | tese | Reproduzido |
| 5.5 | E11 | `constant_off_accuracy_pct` | 93.90 | 93.90076485585409 | 93.90 | % | tese | Reproduzido |
| 5.5 | E11 | `constant_off_balanced_pct` | 50.00 | 50.0 | 50.00 | % | tese | Reproduzido |
| 5.6 | E13 | `buffered` | 499 | 499 | 499 | events | bruto | Reproduzido |
| 5.6 | E13 | `drained` | 499 | 499 | 499 | events | bruto | Reproduzido |
| 5.6 | E13 | `buffered_found_rds` | 499 | 499 | 499 | events | bruto | Reproduzido |
| 5.6 | E13 | `pending` | 0 | 0 | 0 | events | bruto | Reproduzido |
| 5.6 | E13 | `sequence_gap_count` | 0 | 0 | 0 | gaps | bruto | Reproduzido |
| 5.6 | E13 | `buffer_age_max_s` | 375.400 | 375.400148 | 375.400 | s | bruto | Reproduzido |
| 5.6 | E13 | `rds_ingestion_gap_max_s` | 372.478 | 372.478431 | 372.478 | s | bruto | Reproduzido |
| 5.6 | E13 | `latency_max_ms` | 376891.7 | 376891.718 | 376891.7 | ms | bruto | Reproduzido |
| 5.6 | E13 | `ack_mean_ms` | 32.962 | 32.96219264131154 | 32.962 | ms | bruto | Reproduzido |
| 5.6 | E13 | `ack_p95_ms` | 47.768 | 47.7675 | 47.768 | ms | bruto | Reproduzido |
| 5.6 | E12D | `buffered` | 88 | 88 | 88 | events | tese | Reproduzido |
| 5.6 | E12D | `buffer_age_max_s` | 186.7 | 186.706009 | 186.7 | s | tese | Reproduzido |
| 5.6 | E12D | `rds_ingestion_gap_max_s` | 187.7 | 187.659937 | 187.7 | s | tese | Reproduzido |
| 5.6 | E12D | `latency_max_s` | 188.2 | 188.183631 | 188.2 | s | tese | Reproduzido |
| 5.6 | E12 | `rds_ingestion_gap_max_s` | 68.649 | 68.648715 | 68.649 | s | tese | Reproduzido |
| 5.6 | E12 | `buffered_events` | 0 | 0 | 0 | events | tese | Reproduzido |
| 5.7 | E14 | `HOLD_OFF` | 575 | 575 | 575 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `HOLD_ON` | 184 | 184 | 184 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `HOLD_SAFE_OFF` | 93 | 93 | 93 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `SWITCH_ON` | 1 | 1 | 1 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `SWITCH_OFF` | 1 | 1 | 1 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `total` | 854 | 854 | 854 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `safe_off_no_cloud_data` | 93 | 93 | 93 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `age_count` | 761 | 761 | 761 | decisions | bruto | Reproduzido |
| 5.7 | E14 | `age_min_s` | 0.9465 | 0.946505 | 0.9465 | s | bruto | Reproduzido |
| 5.7 | E14 | `age_max_s` | 2.9323 | 2.932271 | 2.9323 | s | bruto | Reproduzido |
| 5.7 | E14 | `duration_min` | 29.98 | 29.98082555 | 29.98 | min | bruto | Reproduzido |
| 5.7 | E14 | `mean_interval_s` | 2.11 | 2.108850566236811 | 2.11 | s | bruto | Reproduzido |

## Fontes por cálculo

- 5.1, E01: `dados/brutos/E01/sensor_readings_cloud_full_export.csv`
- 5.1, E01R: `dados/brutos/E01R/sensor_readings_cloud_full_export.csv`
- 5.1, E02: `dados/brutos/E02/sensor_readings_cloud_full_export.csv`
- 5.1, E03: `dados/brutos/E03/sensor_readings_cloud_full_export.csv`
- 5.1, E06: `dados/brutos/E06/sensor_readings_cloud_full_export.csv`
- 5.1, E09B: `dados/brutos/E09B/sensor_readings_cloud_full_export.csv`
- 5.1, E09C: `dados/brutos/E09C/sensor_readings_cloud_full_export.csv`
- 5.1, E11: `dados/brutos/E11/sensor_readings_cloud_full_export.csv`
- 5.1, E14: `dados/brutos/E14/sensor_readings_cloud_full_export.csv`
- 5.2, E13: `dados/brutos/E13/sensor_readings_cloud_full_export.csv`; `dados/series_preservadas/E13/exp5_cloud_three_state_digital_twin.csv`
- 5.2, E14: `dados/brutos/E14/sensor_readings_cloud_full_export.csv`; `dados/series_preservadas/E14/exp5_cloud_three_state_digital_twin.csv`
- 5.5, E11: `dados/brutos/E11/sensor_readings_cloud_full_export.csv`
- 5.5, E13: `dados/brutos/E13/sensor_readings_cloud_full_export.csv`
- 5.6, E12: `dados/brutos/E12/edge_delivery_audit_3state.jsonl`; `dados/brutos/E12/sensor_readings_cloud_full_export.csv`
- 5.6, E12D: `dados/brutos/E12D/edge_delivery_audit_3state.jsonl`; `dados/brutos/E12D/sensor_readings_cloud_full_export.csv`
- 5.6, E13: `dados/brutos/E13/edge_delivery_audit_3state.jsonl`; `dados/brutos/E13/sensor_readings_cloud_full_export.csv`
- 5.7, E14: `dados/brutos/E14/e14_onoff_shadow_control_decisions.csv`

## Evidência de execução

`verificacao/` preserva comparação, saída do pytest, JUnit XML, ambiente e varredura. `verificacao/hashes_codigo.json` identifica os scripts, testes, requisitos e especificação dos valores esperados desta revisão. As execuções futuras escrevem em `saida/` e não substituem silenciosamente essa evidência arquivada.
