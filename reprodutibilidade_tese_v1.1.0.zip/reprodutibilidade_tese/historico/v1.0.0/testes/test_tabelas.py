"""One regression test per expected value plus small independent unit cases."""
import ast
import hashlib
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT / 'scripts'))
from comum import ROOT as CALC_ROOT, check_hashes, csv_rows, json_read, quantile, relative_path, seconds, timestamp
from gerar_tudo import generate
from tabela_5_2_erro_termico import error_stats, unique_index
from tabela_5_5_concordancia import agreement
from tabela_5_6_recuperacao import delivery_key
from verificar_resultados import compare, rounded

EXPECTED = json_read(ROOT / 'esperado/valores_tese.json')['values']


@pytest.fixture(scope='session')
def compared():
    return {(r['table'],r['run'],r['metric']):r for r in compare(generate())}


@pytest.mark.parametrize('item',EXPECTED,ids=lambda x:f"{x['table']}-{x['run']}-{x['metric']}")
def test_valor_tese(item,compared):
    row = compared[item['table'],item['run'],item['metric']]
    if row['status']=='nao_reproduzivel':
        pytest.skip(row['note'])
    assert row['status']=='reproduzido', f"esperado={row['expected']}; calculado={row['calculated']}; procedencia={row['provenance']}; fontes={row['sources']}"


def test_sha256_copias():
    check_hashes()


def test_calculos_independentes_dos_esperados():
    for path in (ROOT / 'scripts').glob('*.py'):
        if path.name not in ('comum.py','gerar_tudo.py') and not path.name.startswith('tabela_'):
            continue
        source = path.read_text(encoding='utf-8')
        assert 'valores_tese' not in source
        assert 'resumo_historico' not in source
        tree = ast.parse(source)
        assert not any(isinstance(n, ast.ImportFrom) and n.module=='verificar_resultados' for n in ast.walk(tree))


def test_caminhos_fechados_no_pacote():
    assert ROOT == CALC_ROOT
    with pytest.raises(ValueError):
        relative_path('../outside.csv')


def test_quantile_linear():
    assert quantile([0.,10.,20.],.95)==19.


def test_sinal_erro_e_rmse():
    values = error_stats([-2.,1.])
    assert values['bias_c']==-.5
    assert values['mae_c']==1.5
    assert values['rmse_c']==pytest.approx(2.5**.5)


def test_balanceada_e_global_mesmos_pares():
    data = [{'motor_direct_command':'OFF','estimated_command':'OFF'}]*3 + [{'motor_direct_command':'ON','estimated_command':'OFF'}, {'motor_direct_command':'OFF','estimated_command':'UNKNOWN'}]
    values = agreement(data)
    assert values['comparable']==4
    assert values['excluded_unknown']==1
    assert values['agreement_pct']==75
    assert values['balanced_accuracy_pct']==50
    assert values['constant_off_accuracy_pct']==75
    assert values['constant_off_balanced_pct']==50


def test_classe_ausente_nao_inventa_balanceada():
    values = agreement([{'motor_direct_command':'OFF','estimated_command':'OFF'}])
    assert values['balanced_accuracy_pct'] is None


def test_chave_nao_colapsa_reinicio():
    assert delivery_key(1,'2026-09-05T00:00:00Z') != delivery_key(1,'2026-09-05T00:01:00Z')
    assert delivery_key(1,'2026-09-05T00:00:00Z') == delivery_key(1,'2026-09-04T21:00:00-03:00')


def test_juncao_termica_rejeita_duplicata():
    row = {'id':'1','generation_ts':'2026-09-05T00:00:00Z'}
    with pytest.raises(ValueError):
        unique_index([row,row])


def test_precision_timestamps():
    delta = timestamp('2026-09-05T00:00:00.001001Z') - timestamp('2026-09-05T00:00:00Z')
    assert str(seconds(delta))=='0.001001'


def test_arredondamento_declarado():
    assert str(rounded('1.235',2))=='1.24'
    assert str(rounded('1.245',2))=='1.24'


def test_entrada_ausente_nao_gera_aprovacao():
    report = compare([])
    assert all(row['status']=='nao_reproduzivel' for row in report)


def test_calculo_sem_leitura_externa(monkeypatch):
    original = Path.open
    def local_only(path,*args,**kwargs):
        path.resolve().relative_to(ROOT)
        return original(path,*args,**kwargs)
    csv_rows.cache_clear()
    monkeypatch.setattr(Path,'open',local_only)
    assert generate()
