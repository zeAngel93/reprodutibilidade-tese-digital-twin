# Reprodutibilidade das tabelas da tese

Este pacote recalcula as Tabelas 5.1, 5.2, 5.5, 5.6 e 5.7 especificadas pelo autor, além do caso suplementar E12. Não executa a bancada, não acessa AWS ou Kafka e não exige arquivos do projeto original. Não é uma distribuição operacional da aplicação. As Tabelas 5.3 e 5.4 não foram especificadas neste pedido e não estão contempladas.

## Instalação e execução

Ambiente de referência: Python 3.11. Os cálculos usam apenas a biblioteca padrão; `requirements.txt` fixa as dependências dos testes. Após obter o pacote, abra um terminal **dentro desta pasta**.

No PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -B scripts\gerar_tudo.py
.\.venv\Scripts\python.exe -B scripts\verificar_resultados.py
.\.venv\Scripts\python.exe -B -m pytest testes -q --junitxml=saida\testes.xml
```

Em Linux/macOS, use `python3.11 -m venv .venv` e `.venv/bin/python` nos mesmos comandos, com `/` nos caminhos. Apenas a instalação das dependências requer internet. As análises e os testes usam exclusivamente as cópias locais.

**Divergências são preservadas:** a verificação retorna código 1 quando há discrepâncias ou valores não reproduzíveis; os testes correspondentes falham ou são explicitamente não executados. Não ajuste dados ou arredondamentos para obter aprovação. Consulte `RELATORIO_GERACAO.md` antes de interpretar a execução.

| Tabela da tese | Comando, após `python -B` | Arquivo de saída principal |
|---|---|---|
| 5.1 — latência | `scripts/tabela_5_1_latencia.py` | `saida/tabela_5_1_latencia.csv` |
| 5.2 — erro térmico | `scripts/tabela_5_2_erro_termico.py` | `saida/tabela_5_2_erro_termico.csv` |
| 5.5 — concordância | `scripts/tabela_5_5_concordancia.py` | `saida/tabela_5_5_concordancia.csv` |
| 5.6 — recuperação, incluindo E12 suplementar | `scripts/tabela_5_6_recuperacao.py` | `saida/tabela_5_6_recuperacao.csv` |
| 5.7 — supervisão | `scripts/tabela_5_7_supervisao.py` | `saida/tabela_5_7_supervisao.csv` |
| Todas | `scripts/gerar_tudo.py` | Todos os CSV/JSON e conciliações de identificadores |
| Comparação com a tese | `scripts/verificar_resultados.py` | `saida/verificacao_valores.json` e `.md` |
| Auditoria de publicação | `scripts/auditar_pacote.py` | `saida/seguranca.json` |

Cada linha de saída identifica a fonte, o ensaio, a unidade e o método. O diretório `saida/` é regenerável e ignorado pelo Git. Os arquivos de evidência da execução realizada na geração do pacote são preservados separadamente em `verificacao/`.

## Fontes e métodos

- `dados/brutos/`: cópias byte a byte dos CSV de observações, auditorias JSONL e decisões originais selecionados. SHA-256, origem relativa ao projeto e tamanho estão em `dados/MANIFESTO.md` e `dados/manifesto.json`. Nenhuma amostra foi editada, excluída ou sintetizada.
- `dados/series_preservadas/`: previsões históricas **derivadas**, por amostra, copiadas sem alteração. Foram separadas dos dados brutos para não confundir saída do modelo com medição. A Tabela 5.2 recalcula os erros por junção de `id` e instante UTC com a referência processada do CSV bruto. Isso reproduz métricas das previsões arquivadas, não a execução histórica do modelo. Sem a vinculação inequívoca de versão/configuração ao ensaio, a geração original dessas previsões não é reproduzível a partir do pacote.
- `esperado/`: valores fornecidos pelo autor e cópia do resumo histórico indicado para a Tabela 5.1. A procedência `bruto` ou `tese` é a classificação declarada pelo autor, não uma certificação automática. O resumo consolidado é fonte **apenas dos valores esperados**, nunca entrada dos scripts de cálculo.
- Latência: diferença entre `ingestion_ts` e `generation_ts`, em milissegundos. Quantil linear na posição `(n-1)*p`, com todos os registros do arquivo, sem corte inicial ou remoção de extremos. A coluna de latência armazenada serve somente à verificação complementar.
- Erro térmico: `e = T_estimada - T_referencia`. O viés é a média desse erro. O resíduo da API tem sinal oposto e é conferido com a inversão correspondente. A referência é a temperatura processada, não uma segunda medição calibrada independente.
- Concordância: somente pares com contato manual e inferência em `ON`/`OFF`. A acurácia global e a balanceada usam os **mesmos pares e a mesma referência GPIO manual**; a balanceada é a média dos recalls de OFF e ON. A diferença decorre da agregação por classe e do desbalanceamento, não de uma melhoria de instrumentação. A regra constante OFF usa exatamente esses pares.
- Recuperação: identificador composto por sequência e instante de geração; mensagens bufferizadas e drenadas são conjuntos distintos, confrontados com o RDS. Contagens de eventos também são preservadas. A idade do buffer é o campo registrado no evento de drenagem, não o tempo sem broker. O ACK inclui os eventos diretos e drenados com medição disponível. Lacunas de sequência são internas ao conjunto observado e não demonstram entrega integral nem amostragem contínua.
- Supervisão: contagem das decisões arquivadas. A duração do supervisor é distinta da duração de coleta térmica. Recomendações e eventos do operador não demonstram acionamento automático.
- Tolerância: comparação por arredondamento decimal `ROUND_HALF_EVEN` na precisão fornecida. Na Tabela 5.1 conserva-se a precisão literal do CSV indicado, pois outra precisão da tese não foi fornecida. Não há tolerância percentual adicional.

## Limitações que acompanham os resultados

1. E09A: não há dados brutos preservados; comparação Wi-Fi/Ethernet não reproduzível a partir do pacote. Faltam o CSV integral e a auditoria do ensaio Wi-Fi.
2. GPIO17: contato fechado manualmente pelo operador em paralelo à manobra do motor. É independente da cadeia térmica, mas **não mede automaticamente a energização**.
3. E14: sem referência GPIO registrada. As decisões preservadas indicam modo `shadow`; as manobras foram manuais, não por relé comandado e verificado.
4. Relógios de borda e nuvem não sincronizados fisicamente. A diferença entre timestamps contém eventual desvio de relógio; não é uma medição calibrada de atraso unidirecional. Configuração de NTP, por si só, não fornece essa calibração.
5. E13: recuperar todas as mensagens do buffer não implica provar entrega de todos os eventos do ensaio. A conciliação preserva também os envios diretos ausentes do export e os intervalos das duas fontes, sem atribuir causa não demonstrada.
6. As previsões históricas, as configurações do modelo e as versões atuais do código não devem ser confundidas. O pacote não recalibra parâmetros nem substitui o histórico por resultados novos.
7. A revisão de dados pessoais combinou padrões automáticos e inspeção dos campos e dos eventos manuais. Identificadores de equipamento e endereços privados da bancada foram conservados quando necessários à fidelidade do registro; não são credenciais, mas devem passar pela revisão institucional antes da publicação.

## Publicação

O Git foi inicializado somente nesta pasta, sem remoto, envio ou commit. Consulte `LICENCA_A_DEFINIR.md`: nenhuma licença foi concedida automaticamente. Revise também o relatório e os arquivos antes de adicionar ao Git. Não acrescente configurações de acesso. Arquivos acima de 50 MB devem usar Git LFS ou depósito separado, como Zenodo, em vez de inclusão direta; o relatório registra a checagem de tamanho.
