"""Generate every table using only copied local observations."""
from comum import emit, json_write, OUT
import tabela_5_1_latencia
import tabela_5_2_erro_termico
import tabela_5_5_concordancia
import tabela_5_6_recuperacao
import tabela_5_7_supervisao

MODULES = (tabela_5_1_latencia,tabela_5_2_erro_termico,tabela_5_5_concordancia,tabela_5_6_recuperacao,tabela_5_7_supervisao)


def generate():
    all_rows = []
    for module in MODULES:
        rows = module.calculate()
        emit(module.__name__,rows)
        all_rows.extend(rows)
    json_write(OUT / 'todas_tabelas.json',all_rows)
    return all_rows


if __name__ == '__main__':
    rows = generate()
    print(f'{len(rows)} metricas geradas em saida/; nenhuma consulta externa realizada.')
