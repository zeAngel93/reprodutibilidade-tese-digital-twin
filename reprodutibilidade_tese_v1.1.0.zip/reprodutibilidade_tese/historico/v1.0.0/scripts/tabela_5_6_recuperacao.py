"""Reconcile original delivery events against persisted observations."""
import json
from collections import Counter
from comum import OUT, csv_rows, emit, input_path, json_write, latency_ms, max_gap, mean, metric, missing, number, payload, quantile, source_names, timestamp


def delivery_key(sequence, time):
    return int(sequence), timestamp(time).isoformat()


def event_keys(events, kind):
    return {delivery_key(e['sample_sequence_id'],e['generation_timestamp']) for e in events
            if e.get('event_type')==kind and e.get('sample_sequence_id') is not None and e.get('generation_timestamp')}


def calculate_run(run):
    with input_path(run,'audit').open(encoding='utf-8-sig') as f:
        events = [json.loads(line) for line in f if line.strip()]
    events.sort(key=lambda e: timestamp(e['audit_timestamp_utc']))
    data = csv_rows(run)
    rds_keys, rds_sequences, rds_rows_by_key = set(), [], {}
    for row in data:
        delivery = payload(row['payload']).get('edge_delivery',{})
        seq = delivery.get('sample_sequence_id')
        if seq is not None:
            identifier = delivery_key(seq,row['generation_ts'])
            rds_keys.add(identifier)
            rds_sequences.append(identifier)
            rds_rows_by_key.setdefault(identifier,[]).append(row['id'])
    buffered = event_keys(events,'buffered_local')
    drained = event_keys(events,'drained_to_kafka')
    direct = event_keys(events,'sent_direct_to_kafka')
    generated = buffered | drained | direct
    by_sequence = {}
    for identifier in generated:
        by_sequence.setdefault(identifier[0],set()).add(identifier[1])
    reused_ids = sum(len(times)>1 for times in by_sequence.values())
    seqs = sorted(by_sequence)
    gaps = sum(right-left>1 for left,right in zip(seqs,seqs[1:])) if not reused_ids else None
    ages = [number(e['buffer_age_sec']) for e in events if e.get('event_type')=='drained_to_kafka' and e.get('buffer_age_sec') is not None]
    ack = [number(e['kafka_ack_latency_ms']) for e in events if e.get('event_type') in ('sent_direct_to_kafka','drained_to_kafka') and e.get('kafka_ack_latency_ms') is not None]
    finished = [e['pending_count'] for e in events if e.get('event_type')=='drain_finished' and e.get('pending_count') is not None]
    latencies = [latency_ms(row) for row in data]
    counts = Counter(e['event_type'] for e in events)
    first_rds = min((k[1] for k in rds_keys),default=None)
    last_rds = max((k[1] for k in rds_keys),default=None)
    missing_inside_window = {k for k in generated-rds_keys if first_rds is not None and first_rds <= k[1] <= last_rds}
    values = {
        'buffered':(len(buffered),'events'),'buffered_events':(counts['buffered_local'],'events'),
        'drained':(len(drained),'events'),'buffered_found_rds':(len(buffered & rds_keys),'events'),
        'pending':(int(finished[-1]) if finished else None,'events'),
        'buffered_not_drained':(len(buffered-drained),'events'),'drained_missing_rds':(len(drained-rds_keys),'events'),
        'sequence_gap_count':(gaps,'gaps'),'reused_sequence_ids':(reused_ids,'ids'),
        'buffer_age_max_s':(max(ages,default=None),'s'),
        'rds_ingestion_gap_max_s':(max_gap(data,'ingestion_ts'),'s'),
        'rds_generation_gap_max_s':(max_gap(data,'generation_ts'),'s'),
        'latency_max_ms':(max(latencies,default=None),'ms'),
        'latency_max_s':(max(latencies)/1000 if latencies else None,'s'),
        'ack_samples':(len(ack),'events'),'ack_mean_ms':(mean(ack),'ms'),'ack_p95_ms':(quantile(ack,.95),'ms'),
        'edge_generated_unique':(len(generated),'events'),'rds_unique':(len(rds_keys),'events'),
        'edge_missing_rds':(len(generated-rds_keys),'events'),'direct_missing_rds':(len(direct-rds_keys),'events'),
        'rds_duplicates':(len(rds_sequences)-len(rds_keys),'rows'),
        'edge_missing_in_rds_time_window':(len(missing_inside_window),'events'),
        'drain_failed_events':(counts['drain_failed'],'events'),
    }
    # Keep the unmatched identifiers: zero internal gaps is not evidence of full delivery.
    json_write(OUT / f'{run}_conciliacao_identificadores.json',{
        'key':'sample_sequence_id + generation_timestamp UTC',
        'edge_first_utc':min((k[1] for k in generated),default=None),
        'edge_last_utc':max((k[1] for k in generated),default=None),
        'rds_first_utc':min((k[1] for k in rds_keys),default=None),
        'rds_last_utc':max((k[1] for k in rds_keys),default=None),
        'edge_missing_rds':sorted(generated-rds_keys),
        'direct_missing_rds':sorted(direct-rds_keys),
        'buffered_missing_rds':sorted(buffered-rds_keys),
        'rds_not_in_edge_audit':sorted(rds_keys-generated),
        'missing_inside_rds_generation_window':sorted(missing_inside_window),
        'duplicate_rds_keys':[{'key':k,'row_ids':ids} for k,ids in sorted(rds_rows_by_key.items()) if len(ids)>1],
    })
    sources = source_names(run,'rds','audit')
    note = 'Chave composta sequencia+instante; gaps internos entre IDs observados, nao prova de entrega integral. ACK inclui envios diretos e drenados com medicao. Idade do buffer vem dos eventos de drenagem.'
    return [metric('5.6',run,name,value,unit,sources,note) for name,(value,unit) in values.items()]


def calculate():
    result = []
    for run in ('E12','E12D','E13'):
        try:
            result.extend(calculate_run(run))
        except FileNotFoundError as exc:
            result.append(missing('5.6',run,exc))
    return result


if __name__ == '__main__':
    emit('tabela_5_6_recuperacao',calculate())
