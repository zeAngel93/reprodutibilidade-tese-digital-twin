"""Count actual saved decisions; never infer physical actuation from them."""
from collections import Counter
from comum import csv_rows, emit, mean, metric, missing, number, seconds, source_names, span_min, timestamp


def calculate():
    try:
        data = csv_rows('E14','control')
        counts = Counter(row['action'] for row in data)
        ages = [number(row['data_age_sec']) for row in data if row.get('data_age_sec')]
        times = sorted(timestamp(row['decision_timestamp_utc']) for row in data)
        intervals = [seconds(b-a) for a,b in zip(times,times[1:])]
        values = {name:(value,'decisions') for name,value in counts.items()}
        values.update({
            'total':(len(data),'decisions'),
            'safe_off_no_cloud_data':(sum(row['action']=='HOLD_SAFE_OFF' and row['reason']=='api_status_no_cloud_data' for row in data),'decisions'),
            'age_count':(len(ages),'decisions'),'age_min_s':(min(ages,default=None),'s'),'age_max_s':(max(ages,default=None),'s'),
            'duration_min':(span_min(data,'decision_timestamp_utc'),'min'),'mean_interval_s':(mean(intervals),'s'),
            'actuation_attempted_count':(sum(row.get('actuation_attempted','').lower()=='true' for row in data),'decisions'),
            'gpio_reference_count':(sum(row.get('motor_direct_command') in ('ON','OFF') for row in data),'decisions'),
        })
        return [metric('5.7','E14',name,value,unit,source_names('E14','control'),'Decisoes em modo shadow; execucao manual; janela do supervisor distinta da janela termica') for name,(value,unit) in values.items()]
    except FileNotFoundError as exc:
        return [missing('5.7','E14',exc)]


if __name__ == '__main__':
    emit('tabela_5_7_supervisao',calculate())
