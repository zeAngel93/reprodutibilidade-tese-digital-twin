"""Both accuracy measures use exactly the same manual-contact reference pairs."""
from collections import Counter
from comum import csv_rows, emit, metric, missing, source_names


def agreement(rows):
    states = {'ON','OFF'}
    pairs = [(r.get('motor_direct_command'),r.get('estimated_command')) for r in rows]
    comparable = [(a,b) for a,b in pairs if a in states and b in states]
    counts = Counter(comparable)
    off = sum(a=='OFF' for a,b in comparable)
    on = len(comparable)-off
    n = len(comparable)
    return {
        **{f'{a}_{b}':counts[a,b] for a in ('OFF','ON') for b in ('OFF','ON')},
        'comparable':n,'excluded_unknown':sum(a=='UNKNOWN' or b=='UNKNOWN' for a,b in pairs),
        'excluded_other':sum(a not in states or b not in states for a,b in pairs)-sum(a=='UNKNOWN' or b=='UNKNOWN' for a,b in pairs),
        'agreement_pct':100*(counts['OFF','OFF']+counts['ON','ON'])/n if n else None,
        'balanced_accuracy_pct':50*(counts['OFF','OFF']/off + counts['ON','ON']/on) if off and on else None,
        'constant_off_accuracy_pct':100*off/n if n else None,
        'constant_off_balanced_pct':50*((off/off)+(0/on)) if off and on else None,
    }


def calculate():
    result = []
    for run in ('E11','E13'):
        try:
            sources = source_names(run,'rds')
            for name,value in agreement(csv_rows(run)).items():
                result.append(metric('5.5',run,name,value,'%' if name.endswith('_pct') else 'pairs',sources,'Referencia: contato manual GPIO; nao mede energizacao; balanceada = media dos recalls por classe nos mesmos pares'))
        except FileNotFoundError as exc:
            result.append(missing('5.5',run,exc))
    return result


if __name__ == '__main__':
    emit('tabela_5_5_concordancia',calculate())
