"""Latency from the two original timestamps, not from summary tables."""
from comum import csv_rows, emit, latency_ms, mean, metric, missing, quantile, source_names, Decimal

RUNS = ('E01','E01R','E02','E03','E06','E09B','E09C','E11','E14')


def calculate():
    result = []
    for run in RUNS:
        try:
            data = csv_rows(run)
            sources = source_names(run,'rds')
            values = [latency_ms(row) for row in data]
            stats = {'records':(len(data),'rows'), 'latency_mean_ms':(mean(values),'ms'),
                     'latency_p95_ms':(quantile(values,.95),'ms'), 'latency_max_ms':(max(values,default=None),'ms')}
            for name,(value,unit) in stats.items():
                result.append(metric('5.1',run,name,value,unit,sources,'ingestion_ts - generation_ts; quantil linear (n-1)*p'))
            stored = [abs(value - Decimal(row['end_to_end_latency_ms'])) for row,value in zip(data,values) if row.get('end_to_end_latency_ms')]
            result.append(metric('5.1',run,'stored_latency_max_difference_ms',max(stored,default=None),'ms',sources,'Diagnostico da coluna armazenada; nao substitui os timestamps'))
        except FileNotFoundError as exc:
            result.append(missing('5.1',run,exc))
    return result


if __name__ == '__main__':
    emit('tabela_5_1_latencia',calculate())
