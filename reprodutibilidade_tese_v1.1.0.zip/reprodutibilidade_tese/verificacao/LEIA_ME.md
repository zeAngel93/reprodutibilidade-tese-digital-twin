# Evidências por versão

Os arquivos diretamente nesta pasta preservam a execução da v1.0.0: 90 comparações e 13 verificações auxiliares. Não foram reescritos na revisão. Seus hashes de código correspondem às cópias em `historico/v1.0.0/`.

`v1.1.0/` identifica a nova execução, com 91 comparações e 15 verificações auxiliares. A comparação adicional é o máximo absoluto de E14 na precisão da tese. Os resultados atuais não devem ser confundidos com a revisão documental do autor, que não reexecutou o pytest naquela rodada.
